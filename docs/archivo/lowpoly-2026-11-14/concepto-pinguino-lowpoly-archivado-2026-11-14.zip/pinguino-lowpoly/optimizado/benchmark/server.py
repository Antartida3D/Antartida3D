from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import json, base64
ROOT=Path(__file__).resolve().parent
THREE=Path('/mnt/sda1/code/projects/Antartida3D/packages/react-ui/node_modules/three').resolve()
class Handler(SimpleHTTPRequestHandler):
    def translate_path(self,path):
        path=path.split('?')[0]
        root=THREE if path.startswith('/three/') else ROOT
        relative=path[len('/three/'):] if root==THREE else path.lstrip('/')
        resolved=(root/relative).resolve()
        if not resolved.is_relative_to(root):return str(ROOT/'not-found')
        return str(resolved)
    def end_headers(self):
        self.send_header('Cache-Control','no-store')
        self.send_header('Cross-Origin-Opener-Policy','same-origin')
        self.send_header('Cross-Origin-Embedder-Policy','require-corp')
        super().end_headers()
    def do_POST(self):
        if self.path not in ['/results','/visual','/preview']:
            self.send_error(404);return
        size=int(self.headers.get('Content-Length',0))
        if size>3000000:self.send_error(413);return
        data=json.loads(self.rfile.read(size))
        if self.path=='/preview':
            (ROOT/'optimizado-preview.png').write_bytes(base64.b64decode(data['png'].split(',',1)[1]))
        else:
            destination='browser-results.json' if self.path=='/results' else 'visual-verification.json'
            (ROOT/destination).write_text(json.dumps(data,indent=2))
        self.send_response(200);self.end_headers();self.wfile.write(b'OK')
    def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
print(f'http://127.0.0.1:{server.server_port}',flush=True)
server.serve_forever()


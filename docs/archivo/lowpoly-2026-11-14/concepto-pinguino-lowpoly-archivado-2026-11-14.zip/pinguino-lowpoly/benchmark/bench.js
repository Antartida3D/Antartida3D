import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
const status=document.querySelector('#status'),button=document.querySelector('#run');
const renderer=new THREE.WebGLRenderer({canvas:document.querySelector('#canvas'),antialias:true,powerPreference:'high-performance'});
renderer.setPixelRatio(1);renderer.setSize(960,640,false);renderer.setClearColor(0xdde9ef);
renderer.toneMapping=THREE.NoToneMapping;renderer.shadowMap.enabled=false;
const gl=renderer.getContext(),timer=gl.getExtension('EXT_disjoint_timer_query_webgl2'),debug=gl.getExtension('WEBGL_debug_renderer_info');
const environment={three:THREE.REVISION,userAgent:navigator.userAgent,hardwareConcurrency:navigator.hardwareConcurrency,
 renderer:debug?gl.getParameter(debug.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER),
 vendor:debug?gl.getParameter(debug.UNMASKED_VENDOR_WEBGL):gl.getParameter(gl.VENDOR),
 webgl:gl.getParameter(gl.VERSION),gpuTimerAvailable:!!timer,isolated:crossOriginIsolated,
 canvas:[960,640],dpr:1,antialias:gl.getContextAttributes().antialias,started:new Date().toISOString()};
const loader=new GLTFLoader();
const [low,voxelGLTF,boxes]=await Promise.all([loader.loadAsync('./lowpoly.glb'),loader.loadAsync('./voxel.glb'),fetch('./voxel-boxes.json').then(r=>r.json())]);
const faces=[
 {c:[[1,-1,-1],[1,1,-1],[1,1,1],[1,-1,1]],s:.82},
 {c:[[-1,-1,1],[-1,1,1],[-1,1,-1],[-1,-1,-1]],s:.7},
 {c:[[-1,1,-1],[-1,1,1],[1,1,1],[1,1,-1]],s:1},
 {c:[[-1,-1,1],[-1,-1,-1],[1,-1,-1],[1,-1,1]],s:.5},
 {c:[[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]],s:.9},
 {c:[[1,-1,-1],[-1,-1,-1],[-1,1,-1],[1,1,-1]],s:.62}];
const pos=[],colors=[],color=new THREE.Color();
for(const [cx,cy,cz,sx,sy,sz,hex] of boxes){color.setHex(hex);
 for(const {c,s} of faces)for(const i of [0,1,2,0,2,3]){
  const [x,y,z]=c[i];pos.push(-(cz+z*sz/2),cy+y*sy/2,cx+x*sx/2);
  colors.push(color.r*s,color.g*s,color.b*s);
 }}
const geom=new THREE.BufferGeometry();
geom.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));geom.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));
const voxel=new THREE.Mesh(geom,new THREE.MeshBasicMaterial({vertexColors:true}));
function normalize(object){const wrapper=new THREE.Group();wrapper.add(object);wrapper.updateMatrixWorld(true);
 const b=new THREE.Box3().setFromObject(wrapper),size=b.getSize(new THREE.Vector3()),center=b.getCenter(new THREE.Vector3());
 object.position.sub(new THREE.Vector3(center.x,b.min.y,center.z));
 wrapper.scale.setScalar(1/size.y);wrapper.updateMatrixWorld(true);return wrapper;}
const models={voxel:normalize(voxel),lowpoly:normalize(low.scene)};
// Benchmark-only copy: same triangles, flat normals, PBR roughness, double-sided surface;
// move material colors to per-vertex attributes and flatten parts. No source model changes.
const parts=[];
models.lowpoly.traverse(o=>{if(!o.isMesh)return;
 const g=o.geometry.index?o.geometry.toNonIndexed():o.geometry.clone();g.applyMatrix4(o.matrixWorld);
 const c=new Float32Array(g.attributes.position.count*3);for(let i=0;i<c.length;i+=3)o.material.color.toArray(c,i);
 g.setAttribute('color',new THREE.BufferAttribute(c,3));g.clearGroups();parts.push(g);
});
models.lowpoly_merged=new THREE.Mesh(mergeGeometries(parts,false),new THREE.MeshStandardMaterial({vertexColors:true,roughness:.82,metalness:0,side:THREE.DoubleSide}));
function buffers(obj){const arrays=new Set(),materials=new Set();let meshCount=0,triangles=0,vertices=0;
 obj.traverse(o=>{if(!o.isMesh)return;meshCount++;materials.add(o.material);vertices+=o.geometry.attributes.position.count;triangles+=(o.geometry.index?.count??o.geometry.attributes.position.count)/3;
  for(const a of Object.values(o.geometry.attributes))arrays.add(a.array);if(o.geometry.index)arrays.add(o.geometry.index.array);});
 return {meshCount,materials:materials.size,verticesSubmittedAcrossMeshes:vertices,triangles,geometryAttributeAndIndexBytes:[...arrays].reduce((sum,a)=>sum+a.byteLength,0)};}
const assetStats=Object.fromEntries(Object.entries(models).map(([key,m])=>[key,buffers(m)]));
assetStats.voxel_glb=buffers(voxelGLTF.scene);
const camera=new THREE.OrthographicCamera(-1.125,1.125,.75,-.75,.01,100);
camera.position.set(2,1.5,4);camera.lookAt(0,.5,0);
function makeScene(model,n){
 const s=new THREE.Scene();s.add(new THREE.HemisphereLight(0xffffff,0x566878,2));
 const light=new THREE.DirectionalLight(0xffffff,3);light.position.set(-3,5,4);s.add(light);
 const group=new THREE.Group();const side=Math.sqrt(n),scale=n===1?1:1/side;
 for(let i=0;i<n;i++){const c=model.clone(true);c.scale.multiplyScalar(scale);
  if(n>1){c.position.x=(i%side-(side-1)/2)*.19;c.position.y=Math.floor(i/side)*.12;}
  c.traverse(o=>{o.frustumCulled=false;});group.add(c);
 }s.add(group);s.updateMatrixWorld(true);return s;
}
const cases=[];for(const count of [1,100])for(const key of Object.keys(models))cases.push({key,count,scene:makeScene(models[key],count)});
const pause=ms=>new Promise(r=>setTimeout(r,ms));
function stats(values){const a=values.filter(x=>x!==null).sort((a,b)=>a-b);if(!a.length)return null;
 return {n:a.length,median:a[Math.floor(a.length*.5)],p95:a[Math.min(a.length-1,Math.floor(a.length*.95))],mean:a.reduce((x,y)=>x+y,0)/a.length,min:a[0],max:a[a.length-1]};}
async function sample(scene){
 if(timer){
  const q=gl.createQuery();gl.beginQuery(timer.TIME_ELAPSED_EXT,q);
  const start=performance.now();renderer.render(scene,camera);const cpu=performance.now()-start;
  gl.endQuery(timer.TIME_ELAPSED_EXT);gl.flush();
  let tries=0;while(!gl.getQueryParameter(q,gl.QUERY_RESULT_AVAILABLE)){await pause(2);if(++tries>1000)throw new Error('GPU query timeout');}
  const disjoint=gl.getParameter(timer.GPU_DISJOINT_EXT),gpu=disjoint?null:gl.getQueryParameter(q,gl.QUERY_RESULT)/1e6;gl.deleteQuery(q);
  return {cpu,gpu,disjoint};
 }
 gl.finish();const start=performance.now();renderer.render(scene,camera);const cpu=performance.now()-start;gl.finish();
 const completed=performance.now()-start;await pause(2);return {cpu,gpu:null,completed};
}
renderer.render(cases[1].scene,camera);
status.textContent='Listo. '+environment.renderer;button.disabled=false;
button.onclick=async()=>{
 button.disabled=true;const raw=[],runSummaries=[];const begin=performance.now();
 try{
  // Warm every shader and every instance arrangement before timing.
  for(const c of cases){status.textContent='Calentando '+c.key+' × '+c.count;await renderer.compileAsync(c.scene,camera);
   for(let i=0;i<60;i++)renderer.render(c.scene,camera);gl.finish();await pause(20);}
  for(let run=0;run<4;run++){
   const order=run%2?[...cases].reverse():cases;
   for(const c of order){
    status.textContent='Pasada '+(run+1)+'/4 · '+c.key+' × '+c.count;
    for(let i=0;i<10;i++)renderer.render(c.scene,camera);gl.finish();await pause(10);
    const samples=[];for(let i=0;i<60;i++)samples.push(await sample(c.scene));
    const draw={calls:renderer.info.render.calls,triangles:renderer.info.render.triangles};
    raw.push({run,key:c.key,count:c.count,draw,samples});
    runSummaries.push({run,key:c.key,count:c.count,draw,cpuMs:stats(samples.map(s=>s.cpu)),gpuMs:stats(samples.map(s=>s.gpu)),completedMs:stats(samples.map(s=>s.completed??null))});
   }
  }
  const aggregate=cases.map(c=>{
   const rounds=raw.filter(r=>r.key===c.key&&r.count===c.count),s=rounds.flatMap(r=>r.samples);
   return {key:c.key,count:c.count,draw:rounds[0].draw,cpuMs:stats(s.map(x=>x.cpu)),gpuMs:stats(s.map(x=>x.gpu)),completedMs:stats(s.map(x=>x.completed??null)),perRunCpuMedians:rounds.map(r=>stats(r.samples.map(x=>x.cpu)).median),perRunGpuMedians:rounds.map(r=>stats(r.samples.map(x=>x.gpu))?.median??null)};
  });
  const result={environment,method:{warmup:60,blocks:4,samplesPerBlock:60,alternatingOrder:true,shadows:false,textures:false,instancesSharedGeometry:true,instancedMesh:false,cpuMetric:'duration of renderer.render() submission, not complete GPU frame',gpuMetric:timer?'EXT_disjoint_timer_query_webgl2 elapsed, invalid disjoint samples excluded':'unavailable; completedMs uses gl.finish and is CPU+GPU synchronous latency, not GPU alone'},assetStats,aggregate,runSummaries,raw,totalSeconds:(performance.now()-begin)/1000,finished:new Date().toISOString()};
  document.querySelector('#results').textContent=JSON.stringify(result,null,2);
  const format=x=>x?.median.toFixed(3)??'—';
  document.querySelector('#summary').innerHTML='<table><tr><th>Modelo</th><th>Copias</th><th>Dibujos</th><th>Triángulos</th><th>CPU ms</th><th>GPU ms</th><th>CPU+GPU síncrono</th></tr>'+aggregate.map(r=>'<tr><td>'+r.key+'</td><td>'+r.count+'</td><td>'+r.draw.calls+'</td><td>'+r.draw.triangles+'</td><td>'+format(r.cpuMs)+'</td><td>'+format(r.gpuMs)+'</td><td>'+format(r.completedMs)+'</td></tr>').join('')+'</table>';
  const save=await fetch('/results',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(result)});if(!save.ok)throw new Error('No se pudieron guardar los datos');
  status.textContent='Medición completa y guardada · '+result.totalSeconds.toFixed(1)+' s';
  renderer.render(cases[1].scene,camera);
 }catch(e){status.textContent='Error: '+e.message;console.error(e);}finally{button.disabled=false;}
};


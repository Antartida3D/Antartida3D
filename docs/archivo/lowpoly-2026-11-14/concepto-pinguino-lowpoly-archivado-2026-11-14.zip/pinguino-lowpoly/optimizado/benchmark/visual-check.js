// Imported after benchmark setup; the exported function is called only by the UI.
export async function verifyVisuals({THREE,renderer,camera,models,makeScene}) {
 const original=makeScene(models.lowpoly,1),optimized=makeScene(models.optimized,1);
 const renderTarget=new THREE.WebGLRenderTarget(960,640,{depthBuffer:true});
 const a=new Uint8Array(960*640*4),b=new Uint8Array(a.length);
 const oldPosition=camera.position.clone(),oldQuaternion=camera.quaternion.clone(),oldClear=renderer.getClearColor(new THREE.Color()),oldAlpha=renderer.getClearAlpha();
 const views=[],directions=[[2,1.5,4],[-2,1.5,4],[2,1.5,-4],[0,1.2,4]];
 renderer.setClearColor(0,0);
 try {
  for(const direction of directions){
   camera.position.set(...direction);camera.lookAt(0,.5,0);
   renderer.setRenderTarget(renderTarget);renderer.render(original,camera);renderer.readRenderTargetPixels(renderTarget,0,0,960,640,a);
   renderer.render(optimized,camera);renderer.readRenderTargetPixels(renderTarget,0,0,960,640,b);
   let foreground=0,silhouetteMismatch=0,error=0,maxError=0,changedOver2=0;
   for(let i=0;i<a.length;i+=4){
    if(a[i+3]===0&&b[i+3]===0)continue;
    foreground++;if((a[i+3]>127)!==(b[i+3]>127))silhouetteMismatch++;
    let pixelMax=0;for(let k=0;k<3;k++){const diff=Math.abs(a[i+k]-b[i+k]);error+=diff;pixelMax=Math.max(pixelMax,diff);maxError=Math.max(maxError,diff);}
    if(pixelMax>2)changedOver2++;
   }
   views.push({direction,foregroundPixels:foreground,silhouetteMismatchPixels:silhouetteMismatch,
    meanAbsoluteRgbDifference:error/(3*foreground),maxChannelDifference:maxError,pixelsOver2Levels:changedOver2,
    percentPixelsOver2Levels:100*changedOver2/foreground});
  }
 }finally{
  renderer.setRenderTarget(null);renderTarget.dispose();renderer.setClearColor(oldClear,oldAlpha);
  camera.position.copy(oldPosition);camera.quaternion.copy(oldQuaternion);
 }
 const meshes=[];models.optimized.traverse(o=>{if(o.isMesh)meshes.push(o);});
 const body=meshes.find(o=>o.name.includes('Cuerpo')),joints=meshes.filter(o=>o!==body);
 models.optimized.updateMatrixWorld(true);const bodyMatrix=body.matrixWorld.clone();
 const originalQuaternions=joints.map(o=>o.quaternion.clone()),pivots=joints.map(o=>o.getWorldPosition(new THREE.Vector3()));
 joints.forEach(o=>o.rotateZ(o.name.includes('Cabeza')?.15:o.name.includes('derecha')?.25:-.25));
 models.optimized.updateMatrixWorld(true);
 const articulation={parts:meshes.map(o=>o.name),independentJoints:joints.length,
  bodyUnchanged:body.matrixWorld.equals(bodyMatrix),
  pivotDisplacements:joints.map((o,i)=>o.getWorldPosition(new THREE.Vector3()).distanceTo(pivots[i]))};
 joints.forEach((o,i)=>o.quaternion.copy(originalQuaternions[i]));models.optimized.updateMatrixWorld(true);
 renderer.render(optimized,camera);
 const material=meshes[0].material;
 return {views,articulation,material:{flatShading:material.flatShading,vertexColors:material.vertexColors,roughness:material.roughness,metalness:material.metalness,side:material.side},
  method:'Same 960x640 offscreen render target, same PBR lights and camera; RGB errors on union of foreground pixels; no antialias in verification target.'};
}


from pathlib import Path
import json,hashlib
p=Path(__file__).resolve().parent
b=p/'benchmark'
d=json.loads((b/'browser-results.json').read_text())
first=json.loads((b/'browser-results-first-pass.json').read_text())
assert d['finished']!=first['finished'],'Final benchmark is not finished yet'
e=json.loads((b/'export-stats.json').read_text())
v=json.loads((b/'visual-verification.json').read_text())
blender=json.loads((p/'blender-verification.json').read_text())
assert blender['source_unchanged'] and blender['triangles']==726 and blender['materials']==1
assert all(r['geometry_matches_source'] and r['nonmanifold']==0 and r['degenerate']==0 for r in blender['parts'])
assert all(r['silhouetteMismatchPixels']==0 and r['maxChannelDifference']<=1 for r in v['views'])
assert v['articulation']['bodyUnchanged'] and max(v['articulation']['pivotDisplacements'])==0
assert v['material']['flatShading'] and v['material']['vertexColors']
for row in d['aggregate']:
    assert row['draw']['calls']=={'voxel':1,'lowpoly':30,'optimized':4}[row['key']]*row['count']
    assert row['draw']['triangles']==(216 if row['key']=='voxel' else 726)*row['count']
    assert row['cpuMs']['n']==240 and row['gpuMs']['n']==240
assert hashlib.sha256((p/'pinguino-lowpoly-optimizado.glb').read_bytes()).hexdigest()==e['optimized']['sha256']
labels={'voxel':'Voxel actual','lowpoly':'Low-poly anterior','optimized':'Low-poly optimizado'}
cpu100={r['key']:r['cpuMs']['median'] for r in d['aggregate'] if r['count']==100}
gpu100={r['key']:r['gpuMs']['median'] for r in d['aggregate'] if r['count']==100}
cpu_reduction=100*(1-cpu100['optimized']/cpu100['lowpoly'])
weight_reduction=100*(1-e['optimized']['fileBytes']/e['lowpoly']['fileBytes'])
memory_reduction=100*(1-d['assetStats']['optimized']['geometryAttributeAndIndexBytes']/d['assetStats']['lowpoly']['geometryAttributeAndIndexBytes'])
lines=[
'# Pingüino low-poly optimizado y nueva comparación',
'',
'14 de noviembre de 2026. Optimización terminada como recurso independiente; sin integración en el repositorio de la aplicación.',
'',
f'**Se conserva la forma de 726 triángulos y la movilidad independiente de cabeza y aletas.** El GLB baja {weight_reduction:.1f} %, los buffers de geometría {memory_reduction:.1f} % y la mediana de CPU con 100 copias {cpu_reduction:.1f} % frente al low-poly anterior.',
'',
'## Cambios realizados',
'',
'- 18 objetos de edición pasan a 4: cuerpo (incluye patas, uñas y cola), cabeza (incluye ojos y pico) y ambas aletas.',
'- 15 materiales pasan a 1 material PBR: los colores se almacenan por esquina de cara en Blender y por vértice en el GLB. Se conserva rugosidad 0,82, metalicidad 0 y doble cara.',
'- Se exportan posiciones, colores e índices; se omiten normales redundantes. Three.js obtiene las normales planas en el shader, lo que permite compartir vértices entre caras. Los vértices exportados bajan de 1.940 a 581.',
'- Se preservan los pivotes de cabeza y aletas. No se incorporaron un esqueleto ni clips de animación.',
'- Los originales y las mediciones anteriores permanecen intactos.',
'',
'El sombreado plano cuando faltan normales está contemplado por la [especificación glTF 2.0 de Khronos](https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html#meshes). Se comprobó además el comportamiento en GLTFLoader de Three.js 0.187.0. Consulta: 14 de noviembre de 2026.',
'',
'## Peso, memoria y llamadas',
'',
'Animal solo, sin hielo ni presentación. KiB = 1.024 bytes. Los buffers son atributos e índices cargados por Three.js, no toda la RAM o VRAM del proceso.',
'',
'| Medida | Voxel | Low-poly anterior | Optimizado |',
'|---|---:|---:|---:|',
'| Triángulos | 216 | 726 | 726 |',
'| Materiales | 1 | 15 | 1 |',
'| Llamadas de dibujo por animal | 1 | 30 | 4 |',
'| Vértices de atributos de posición | 648 | 1.940 | 581 |',
]
for label,metric in [('GLB','fileBytes'),('GLB con gzip nivel 9','gzipBytes')]:
    values=[f"{e[k][metric]/1024:.2f} KiB" for k in labels]
    lines.append('| '+label+' | '+' | '.join(values)+' |')
values=[f"{d['assetStats'][k]['geometryAttributeAndIndexBytes']/1024:.2f} KiB" for k in labels]
lines += ['| Buffers de la representación medida | '+' | '.join(values)+' |','',
'El GLB optimizado sin compresión es menor que el GLB del voxel. Con gzip, el voxel sigue siendo menor. Además, el voxel real de la aplicación se construye por código y no descarga un GLB: su archivo aquí sirve para comparar formatos. Sus buffers cargados desde GLB serían 21,52 KiB; la representación real medida usa 15,19 KiB.',
'',
'## Rendimiento',
'',
'Se volvieron a medir los tres recursos juntos en Intel UHD Graphics (CML GT2), ANGLE/Mesa, Chromium 152, WebGL 2 y Three.js 0.187.0. Lienzo 960 × 640, DPR 1, antialias, cámara y altura normalizada iguales, sin sombras, hielo, texturas ni animación. El voxel conserva su material sin luces y ambos low-poly su material PBR iluminado.',
'',
'Por caso: 60 dibujos de calentamiento, cuatro bloques alternando el orden y 60 muestras por bloque (240). Se midieron 1 y 100 copias compartiendo geometrías y materiales; no se usó InstancedMesh. La prueba reproduce el protocolo anterior. No mide carga inicial, React, juego completo ni composición de pantalla.',
'',
'CPU = duración de renderer.render() al preparar/enviar comandos. GPU = consulta EXT_disjoint_timer_query_webgl2. No se suman ni se convierten directamente a FPS. Se informan las medianas y el percentil 95 de la segunda ejecución, sin cambios de vista de Blender durante la medición.',
'',
'| Modelo | Copias | Llamadas | CPU mediana (ms) | CPU P95 | GPU mediana (ms) | GPU P95 |',
'|---|---:|---:|---:|---:|---:|---:|']
for r in d['aggregate']:
    lines.append(f"| {labels[r['key']]} | {r['count']} | {r['draw']['calls']} | {r['cpuMs']['median']:.3f} | {r['cpuMs']['p95']:.3f} | {r['gpuMs']['median']:.3f} | {r['gpuMs']['p95']:.3f} |")
lines += ['',
'La primera ejecución se conservó como referencia. Se repitió porque se había cambiado la vista de Blender durante la prueba y los tiempos GPU variaron. No se seleccionó el mejor bloque: cada cifra principal agrega las 240 muestras de la segunda ejecución.',
'',
'| Caso de 100 copias | CPU 1.ª ejecución | CPU 2.ª ejecución | GPU 1.ª ejecución | GPU 2.ª ejecución |',
'|---|---:|---:|---:|---:|']
for key in labels:
    r=next(x for x in first['aggregate'] if x['key']==key and x['count']==100)
    lines.append(f"| {labels[key]} | {r['cpuMs']['median']:.3f} | {cpu100[key]:.3f} | {r['gpuMs']['median']:.3f} | {gpu100[key]:.3f} |")
lines += ['',
'Los tiempos GPU dependen de la carga de este equipo compartido y muestran variación entre ejecuciones; el porcentaje de mejora no debe extrapolarse como una constante a otros dispositivos. El descenso de llamadas (3.000 → 400 con 100 animales), archivo y buffers es determinista para estos recursos.',
'',
'## Verificación de calidad',
'',
'- Blender: mismas posiciones y triangulación por pieza respecto al original, con comparación redondeada a seis decimales. Se verificaron 726 triángulos, ausencia de caras degeneradas y aristas no manifold.',
'- Navegador: cuatro vistas del original y el optimizado con la misma cámara e iluminación. Cero píxeles diferentes en la silueta; diferencia máxima de 1 nivel sobre 255 por canal RGB. La diferencia media por canal en el primer plano fue inferior a 0,013 niveles.',
'- Rotación de las tres piezas articulables: pivotes sin desplazamiento y cuerpo inmóvil; transformaciones restauradas al finalizar.',
'- Contadores reales: 4 llamadas y 726 triángulos por animal; 400 llamadas y 72.600 triángulos con 100 copias.',
'',
'## Entrega y uso',
'',
'- [Modelo optimizado de Blender](pinguino-lowpoly-optimizado.blend)',
'- [GLB optimizado](pinguino-lowpoly-optimizado.glb)',
'- [Vista del GLB en el navegador](benchmark/optimizado-preview.png)',
'- [Referencias visuales y procedencia](Referencias.txt)',
'- [Datos completos de la segunda ejecución](benchmark/browser-results.json)',
'- [Primera ejecución](benchmark/browser-results-first-pass.json)',
'- [Verificación visual y articulaciones](benchmark/visual-verification.json)',
'- [Verificación geométrica en Blender](blender-verification.json)',
'- [Estadísticas de archivos y hashes](benchmark/export-stats.json)',
'- [Prueba reproducible](benchmark/index.html) y [servidor local](benchmark/server.py)',
'- [Script que produjo la optimización](../optimizar_blender.py)',
'',
'En Blender queda activa la escena «Antartida3D - Emperador optimizado - ee68». El archivo .blend contiene esta escena con su presentación; el GLB incluye solo el animal.',
'',
'Para volver a exportar desde Blender: seleccionar raíz y cuatro piezas, exportar solo selección y escena activa, colores activos, sin normales, UV ni animación. Para repetir las mediciones: ejecutar python3 server.py dentro de benchmark, abrir la dirección local impresa, verificar apariencia y luego medir. Usa la instalación de Three.js ya presente en el equipo, sin instalar paquetes.',
'',
'El siguiente paso de integración, si se solicita, es cargar el GLB en la aplicación y verificar allí el comportamiento con su iluminación y cantidad real de animales. Este estudio no modifica código, issues ni ramas del repositorio.',
'',
'Modelo, scripts y optimización elaborados con asistencia de IA. Las fotos se usaron como referencia; no se incorporan texturas de terceros.'
]
(p/'Comparacion-optimizacion.md').write_text('\n'.join(lines)+'\n')
(b/'verification.json').write_text(json.dumps({'checks':'passed','cases':6,'gpu_samples':1440,'silhouette_mismatch_pixels':0,'max_color_error_255':1,'source_unchanged':True,'cpu_reduction_100_percent':cpu_reduction,'glb_reduction_percent':weight_reduction,'buffer_reduction_percent':memory_reduction},indent=2))
print(json.dumps({'report':str(p/'Comparacion-optimizacion.md'),'cpu_reduction':cpu_reduction,'weight_reduction':weight_reduction,'memory_reduction':memory_reduction,'cpu100':cpu100,'gpu100':gpu100},indent=2))


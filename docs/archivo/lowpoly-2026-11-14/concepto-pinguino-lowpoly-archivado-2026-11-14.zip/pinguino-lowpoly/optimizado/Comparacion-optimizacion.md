# Pingüino low-poly optimizado y nueva comparación

14 de noviembre de 2026. Optimización terminada como recurso independiente; sin integración en el repositorio de la aplicación.

**Se conserva la forma de 726 triángulos y la movilidad independiente de cabeza y aletas.** El GLB baja 73.2 %, los buffers de geometría 68.3 % y la mediana de CPU con 100 copias 85.4 % frente al low-poly anterior.

## Cambios realizados

- 18 objetos de edición pasan a 4: cuerpo (incluye patas, uñas y cola), cabeza (incluye ojos y pico) y ambas aletas.
- 15 materiales pasan a 1 material PBR: los colores se almacenan por esquina de cara en Blender y por vértice en el GLB. Se conserva rugosidad 0,82, metalicidad 0 y doble cara.
- Se exportan posiciones, colores e índices; se omiten normales redundantes. Three.js obtiene las normales planas en el shader, lo que permite compartir vértices entre caras. Los vértices exportados bajan de 1.940 a 581.
- Se preservan los pivotes de cabeza y aletas. No se incorporaron un esqueleto ni clips de animación.
- Los originales y las mediciones anteriores permanecen intactos.

El sombreado plano cuando faltan normales está contemplado por la [especificación glTF 2.0 de Khronos](https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html#meshes). Se comprobó además el comportamiento en GLTFLoader de Three.js 0.187.0. Consulta: 14 de noviembre de 2026.

## Peso, memoria y llamadas

Animal solo, sin hielo ni presentación. KiB = 1.024 bytes. Los buffers son atributos e índices cargados por Three.js, no toda la RAM o VRAM del proceso.

| Medida | Voxel | Low-poly anterior | Optimizado |
|---|---:|---:|---:|
| Triángulos | 216 | 726 | 726 |
| Materiales | 1 | 15 | 1 |
| Llamadas de dibujo por animal | 1 | 30 | 4 |
| Vértices de atributos de posición | 648 | 1.940 | 581 |
| GLB | 22.85 KiB | 71.18 KiB | 19.09 KiB |
| GLB con gzip nivel 9 | 3.38 KiB | 17.01 KiB | 6.63 KiB |
| Buffers de la representación medida | 15.19 KiB | 49.15 KiB | 15.60 KiB |

El GLB optimizado sin compresión es menor que el GLB del voxel. Con gzip, el voxel sigue siendo menor. Además, el voxel real de la aplicación se construye por código y no descarga un GLB: su archivo aquí sirve para comparar formatos. Sus buffers cargados desde GLB serían 21,52 KiB; la representación real medida usa 15,19 KiB.

## Rendimiento

Se volvieron a medir los tres recursos juntos en Intel UHD Graphics (CML GT2), ANGLE/Mesa, Chromium 152, WebGL 2 y Three.js 0.187.0. Lienzo 960 × 640, DPR 1, antialias, cámara y altura normalizada iguales, sin sombras, hielo, texturas ni animación. El voxel conserva su material sin luces y ambos low-poly su material PBR iluminado.

Por caso: 60 dibujos de calentamiento, cuatro bloques alternando el orden y 60 muestras por bloque (240). Se midieron 1 y 100 copias compartiendo geometrías y materiales; no se usó InstancedMesh. La prueba reproduce el protocolo anterior. No mide carga inicial, React, juego completo ni composición de pantalla.

CPU = duración de renderer.render() al preparar/enviar comandos. GPU = consulta EXT_disjoint_timer_query_webgl2. No se suman ni se convierten directamente a FPS. Se informan las medianas y el percentil 95 de la segunda ejecución, sin cambios de vista de Blender durante la medición.

| Modelo | Copias | Llamadas | CPU mediana (ms) | CPU P95 | GPU mediana (ms) | GPU P95 |
|---|---:|---:|---:|---:|---:|---:|
| Voxel actual | 1 | 1 | 0.095 | 0.145 | 0.223 | 0.250 |
| Low-poly anterior | 1 | 30 | 0.300 | 0.485 | 0.400 | 0.525 |
| Low-poly optimizado | 1 | 4 | 0.140 | 0.220 | 0.373 | 0.414 |
| Voxel actual | 100 | 100 | 0.405 | 0.625 | 0.291 | 0.371 |
| Low-poly anterior | 100 | 3000 | 9.985 | 14.685 | 2.272 | 5.418 |
| Low-poly optimizado | 100 | 400 | 1.460 | 2.195 | 1.432 | 1.881 |

La primera ejecución se conservó como referencia. Se repitió porque se había cambiado la vista de Blender durante la prueba y los tiempos GPU variaron. No se seleccionó el mejor bloque: cada cifra principal agrega las 240 muestras de la segunda ejecución.

| Caso de 100 copias | CPU 1.ª ejecución | CPU 2.ª ejecución | GPU 1.ª ejecución | GPU 2.ª ejecución |
|---|---:|---:|---:|---:|
| Voxel actual | 0.405 | 0.405 | 0.293 | 0.291 |
| Low-poly anterior | 10.275 | 9.985 | 3.418 | 2.272 |
| Low-poly optimizado | 1.405 | 1.460 | 1.360 | 1.432 |

Los tiempos GPU dependen de la carga de este equipo compartido y muestran variación entre ejecuciones; el porcentaje de mejora no debe extrapolarse como una constante a otros dispositivos. El descenso de llamadas (3.000 → 400 con 100 animales), archivo y buffers es determinista para estos recursos.

## Verificación de calidad

- Blender: mismas posiciones y triangulación por pieza respecto al original, con comparación redondeada a seis decimales. Se verificaron 726 triángulos, ausencia de caras degeneradas y aristas no manifold.
- Navegador: cuatro vistas del original y el optimizado con la misma cámara e iluminación. Cero píxeles diferentes en la silueta; diferencia máxima de 1 nivel sobre 255 por canal RGB. La diferencia media por canal en el primer plano fue inferior a 0,013 niveles.
- Rotación de las tres piezas articulables: pivotes sin desplazamiento y cuerpo inmóvil; transformaciones restauradas al finalizar.
- Contadores reales: 4 llamadas y 726 triángulos por animal; 400 llamadas y 72.600 triángulos con 100 copias.

## Entrega y uso

- [Modelo optimizado de Blender](pinguino-lowpoly-optimizado.blend)
- [GLB optimizado](pinguino-lowpoly-optimizado.glb)
- [Vista del GLB en el navegador](benchmark/optimizado-preview.png)
- [Referencias visuales y procedencia](Referencias.txt)
- [Datos completos de la segunda ejecución](benchmark/browser-results.json)
- [Primera ejecución](benchmark/browser-results-first-pass.json)
- [Verificación visual y articulaciones](benchmark/visual-verification.json)
- [Verificación geométrica en Blender](blender-verification.json)
- [Estadísticas de archivos y hashes](benchmark/export-stats.json)
- [Prueba reproducible](benchmark/index.html) y [servidor local](benchmark/server.py)
- [Script que produjo la optimización](../optimizar_blender.py)

En Blender queda activa la escena «Antartida3D - Emperador optimizado - ee68». El archivo .blend contiene esta escena con su presentación; el GLB incluye solo el animal.

Para volver a exportar desde Blender: seleccionar raíz y cuatro piezas, exportar solo selección y escena activa, colores activos, sin normales, UV ni animación. Para repetir las mediciones: ejecutar python3 server.py dentro de benchmark, abrir la dirección local impresa, verificar apariencia y luego medir. Usa la instalación de Three.js ya presente en el equipo, sin instalar paquetes.

El siguiente paso de integración, si se solicita, es cargar el GLB en la aplicación y verificar allí el comportamiento con su iluminación y cantidad real de animales. Este estudio no modifica código, issues ni ramas del repositorio.

Modelo, scripts y optimización elaborados con asistencia de IA. Las fotos se usaron como referencia; no se incorporan texturas de terceros.

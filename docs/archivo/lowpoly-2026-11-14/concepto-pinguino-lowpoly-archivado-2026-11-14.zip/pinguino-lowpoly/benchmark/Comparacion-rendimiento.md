# Comparación medida: pingüino voxel y low-poly

Fecha: 14 de noviembre de 2026. Estudio aislado de los dos modelos existentes, sin modificar la aplicación ni los originales de Blender.

**En su estado actual, el voxel es más liviano y exige menos trabajo de dibujo.** La diferencia de CPU al repetir el low-poly viene principalmente de sus piezas/materiales exportados; reunirlos reduce ese costo de manera considerable. Este resultado compara estos dos recursos concretos, no demuestra que un estilo sea siempre más eficiente que otro.

## Geometría y peso

Comparación del animal solo: se excluyen hielo, cámara, luces, piso y rótulos de presentación. KiB = 1.024 bytes.

| Medida | Voxel | Low-poly |
|---|---:|---:|
| Triángulos | 216 | 726 |
| Vértices en Blender | 648 | 399 |
| Objetos de malla en Blender | 1 | 18 |
| Materiales | 1 | 15 |
| Primitivas de dibujo tras cargar GLB | 1 | 30 |
| Vértices en atributos de posición exportados | 648 | 1.940 |
| GLB sin compresión geométrica | 23.396 B (22,85 KiB) | 72.892 B (71,18 KiB) |
| Ese GLB comprimido con gzip, nivel 9 | 3.458 B (3,38 KiB) | 17.419 B (17,01 KiB) |
| Atributos e índices cargados desde GLB | 22.032 B (21,52 KiB) | 50.328 B (49,15 KiB) |
| Atributos e índices de la representación usada en la prueba | 15.552 B (15,19 KiB) | 50.328 B (49,15 KiB) |
| Texturas | 0 | 0 |

El low-poly tiene **3,36 veces** los triángulos y **3,12 veces** el tamaño GLB. Gzip deja una relación de **5,04 veces**. Los valores de gzip son compresión local de los archivos, no una descarga medida ni una configuración comprobada del servidor de la aplicación.

Los 399 vértices de edición del low-poly no equivalen a los vértices que recibe WebGL: las normales planas y las separaciones de materiales requieren duplicaciones en la exportación. Los 30 grupos de material se cargan como 30 mallas de dibujo en Three.js, aunque Blender tenga 18 objetos.

El voxel de la aplicación se construye por código en una malla con posiciones y colores, sin normales ni índices; **no descarga un GLB**. Por eso se informan por separado el archivo común de comparación y los buffers de su representación real. Estos buffers no son toda la memoria del proceso ni una medición total de VRAM: excluyen objetos JavaScript, shaders, framebuffer y asignaciones internas del controlador.

El hielo aporta 24 triángulos en el voxel y 30 en el low-poly: con hielo, 240 y 756. Se dejó fuera de la prueba de dibujo.

## Rendimiento medido

Equipo de esta sesión: **Intel UHD Graphics (CML GT2)** mediante ANGLE/Mesa, WebGL 2, Chromium 152, Three.js 0.187.0. No fue renderizado por software.

Condiciones: lienzo 960 × 640, DPR 1, antialias activado, cámara ortográfica fija, altura del animal normalizada, sin sombras, sin texturas, sin animación, sin React ni resto de la aplicación. El voxel usa su material original sin iluminación; el low-poly conserva materiales PBR de la exportación con una luz hemisférica y una direccional. Por tanto se compara el costo de las representaciones actuales, que incluyen diferencias de iluminación y caras dobles, no solo el número de triángulos.

Se probaron 1 y 100 copias, compartiendo geometrías/materiales, sin InstancedMesh. Las 100 copias forman una cuadrícula y se reducen para caber en la misma escena. No representa una colonia ya integrada al producto.

Se compilaron los shaders y calentó cada caso con 60 dibujos. Luego se hicieron cuatro pasadas alternando el orden, 60 muestras por caso y pasada; 240 muestras por fila. Hubo 10 dibujos adicionales de calentamiento al cambiar de caso. Las 1.440 consultas GPU fueron válidas, sin muestras disjoint descartadas.

CPU: duración de la llamada renderer.render(), es decir, preparación y envío de comandos. GPU: consulta EXT_disjoint_timer_query_webgl2 alrededor del dibujo. Son mediciones separadas; **no deben sumarse ni convertirse directamente a FPS del juego**. Incluyen el dibujo del lienzo y su limpieza; no se descontó una escena vacía. No incluyen carga, compilación inicial, lógica de juego ni composición final del navegador.

Tiempos en milisegundos. P95 muestra el valor por debajo del cual quedó el 95 % de las muestras.

| Modelo | Copias | Llamadas de dibujo | CPU mediana | CPU P95 | GPU mediana | GPU P95 |
|---|---:|---:|---:|---:|---:|---:|
| Voxel actual | 1 | 1 | 0.100 | 0.165 | 0.212 | 0.247 |
| Low-poly original | 1 | 30 | 0.275 | 0.435 | 0.385 | 0.432 |
| Low-poly reunido (prueba) | 1 | 1 | 0.110 | 0.180 | 0.349 | 0.405 |
| Voxel actual | 100 | 100 | 0.360 | 0.555 | 0.274 | 0.325 |
| Low-poly original | 100 | 3,000 | 9.690 | 12.170 | 1.387 | 5.065 |
| Low-poly reunido (prueba) | 100 | 100 | 0.360 | 0.545 | 1.074 | 1.167 |

Con un animal, la diferencia absoluta es pequeña. Con 100, el low-poly sin consolidar llega a **3.000 llamadas**: la mediana de CPU es unas **26,9 veces** la del voxel. La GPU tiene una mediana de 1,387 ms frente a 0,274 ms, con variación mayor en el P95 del low-poly.

## Qué demuestra la copia reunida

Para la prueba se creó en memoria una copia estática del low-poly: misma geometría de 726 triángulos, mismas normales planas, colores trasladados a vértices, mismo material PBR base, rugosidad 0,82 y caras dobles. Se combinaron las piezas en una malla y un material.

Con 100 copias pasa de 3.000 a 100 llamadas. CPU: **9,690 → 0,360 ms**, reducción del **96,3 %**. GPU: **1,387 → 1,074 ms**, reducción del **22,5 %**. La persistencia de más costo GPU también incluye su iluminación PBR y rasterización, por lo que no se atribuye todo a los triángulos.

Esta copia es una prueba de consolidación, no un recurso final integrado. Pierde los pivotes separados para animar piezas y usa geometría sin índices: sus buffers suben a **78.408 B (76,57 KiB)**. Una optimización de producción debería conservar la movilidad necesaria y trabajar además la indexación/cuantización. El resultado permite decidir el siguiente paso sin alterar el modelo editable.

**Recomendación para estos recursos:** el voxel actual ya está preparado para repetirse con poco costo. Si se adopta la apariencia low-poly, conviene preparar una exportación optimizada antes de colocar muchas copias; no hace falta abandonar esa estética para reducir la sobrecarga de CPU.

## Archivos y reproducción

- [Resultados completos con muestras](browser-results.json)
- [Estadísticas de exportación y hashes](export-stats.json)
- [Estadísticas originales de Blender](blender-stats.json)
- [Verificación de contadores y muestras](verification.json)
- [Procedencia del código y commit](source-provenance.json)
- [Pingüino voxel GLB](voxel.glb) y [pingüino low-poly GLB](lowpoly.glb)
- [Prueba del navegador](index.html), [código](bench.js), [servidor local](server.py)

Los GLB se exportaron desde Blender 5.2.4 seleccionando solo el animal y la escena activa, sin animación, UV, extras ni compresión Draco/Meshopt; con normales y colores activos. El material Emission con color de vértices del voxel no se traduce fielmente con el exportador: en la copia GLB se adaptó a KHR_materials_unlit con base blanca y color de vértices, equivalente al material sin luces de la aplicación. Se conservaron los buffers. La medición principal del voxel reconstruye directamente los 18 bloques originales y el algoritmo de sombreado por cara de vehicles.ts, no usa ese GLB.

Para repetir: ejecutar `python3 server.py` desde esta carpeta, abrir la URL de 127.0.0.1 impresa y pulsar «Medir rendimiento». El servidor usa Three.js ya instalado en `/mnt/sda1/code/projects/Antartida3D/packages/react-ui/node_modules/three`; no instala dependencias ni sirve el proyecto completo. Una nueva ejecución reemplaza browser-results.json. Los valores dependen del equipo, carga del sistema, navegador y encuadre.

Referencias técnicas consultadas el 14 de noviembre de 2026: [Three.js BufferGeometry](https://threejs.org/docs/pages/BufferGeometry.html), que documenta los grupos como llamadas de dibujo separadas, y [WebGLRenderer](https://threejs.org/docs/pages/WebGLRenderer.html), que expone los contadores renderer.info. Los números de este informe proceden de los archivos y de la ejecución local, no de esas referencias.

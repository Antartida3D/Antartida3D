import bpy, json, pathlib, math, bmesh
from mathutils import Matrix, Vector
out=pathlib.Path('/home/gip/.codex/visualizations/2026/11/13/01a1d72a-9ba2-7850-a177-e8787a16cd64/pinguino-lowpoly/optimizado')
out.mkdir(exist_ok=True)
source_root=bpy.data.objects['Emperador low-poly']
source_scene=bpy.data.scenes['Antartida3D - Pinguino low-poly - ee68']
name='Antartida3D - Emperador optimizado - ee68'
assert name not in bpy.data.scenes, 'Optimized scene already exists; inspect before rerunning.'
source_hash={o.name:(len(o.data.vertices),len(o.data.polygons)) for o in source_root.children_recursive if o.type=='MESH'}
scene=bpy.data.scenes.new(name)
scene.render.engine=source_scene.render.engine
scene.world=source_scene.world.copy() if source_scene.world else None
scene.view_settings.view_transform=source_scene.view_settings.view_transform
scene.view_settings.look=source_scene.view_settings.look
scene.render.resolution_x=1000;scene.render.resolution_y=1000;scene.render.resolution_percentage=100
model_collection=bpy.data.collections.new('Emperador optimizado - 4 piezas')
scene.collection.children.link(model_collection)
root=bpy.data.objects.new('Emperador optimizado',None);model_collection.objects.link(root)
root.matrix_world=source_root.matrix_world.copy()
mat=bpy.data.materials.new('ee68 OPT - Colores del plumaje')
mat.use_nodes=True
bsdf=next(n for n in mat.node_tree.nodes if n.type=='BSDF_PRINCIPLED')
bsdf.inputs['Roughness'].default_value=.82;bsdf.inputs['Metallic'].default_value=0
vertex=mat.node_tree.nodes.new('ShaderNodeVertexColor');vertex.layer_name='Col'
mat.node_tree.links.new(vertex.outputs['Color'],bsdf.inputs['Base Color'])
head=bpy.data.objects['Cabeza y cuello'];right=bpy.data.objects['Aleta derecha'];left=bpy.data.objects['Aleta izquierda']
head_parts=[head]+list(head.children_recursive)
body_parts=[o for o in source_root.children_recursive if o.type=='MESH' and o not in head_parts+[right,left]]
groups=[('Cuerpo',source_root,body_parts),('Cabeza',head,head_parts),('Aleta derecha',right,[right]),('Aleta izquierda',left,[left])]
results=[]
for label,anchor,parts in groups:
    verts=[];faces=[];face_colors=[];expected=[]
    inverse=anchor.matrix_world.inverted()
    for obj in parts:
        transform=inverse@obj.matrix_world
        start=len(verts);verts.extend([tuple(transform@v.co) for v in obj.data.vertices])
        for poly in obj.data.polygons:
            faces.append(tuple(start+i for i in poly.vertices))
            oldmat=obj.data.materials[poly.material_index]
            shader=next(n for n in oldmat.node_tree.nodes if n.type=='BSDF_PRINCIPLED')
            face_colors.append(tuple(shader.inputs['Base Color'].default_value))
        obj.data.calc_loop_triangles()
        expected.extend([tuple(sorted(tuple(round(float(c),6) for c in transform@obj.data.vertices[i].co) for i in tri.vertices)) for tri in obj.data.loop_triangles])
    mesh=bpy.data.meshes.new('ee68 OPT - '+label);mesh.from_pydata(verts,[],faces);mesh.update()
    attribute=mesh.color_attributes.new(name='Col',type='FLOAT_COLOR',domain='CORNER')
    for poly,color in zip(mesh.polygons,face_colors):
        for idx in poly.loop_indices:attribute.data[idx].color=color
    mesh.color_attributes.active_color=attribute
    mesh.materials.append(mat);mesh.calc_loop_triangles()
    actual=[tuple(sorted(tuple(round(float(c),6) for c in mesh.vertices[i].co) for i in tri.vertices)) for tri in mesh.loop_triangles]
    assert sorted(actual)==sorted(expected), label+' triangulation changed'
    obj=bpy.data.objects.new('OPT - '+label,mesh);model_collection.objects.link(obj)
    obj.parent=root;obj.matrix_parent_inverse=Matrix.Identity(4)
    obj.matrix_basis=source_root.matrix_world.inverted()@anchor.matrix_world
    obj['role']=label;obj['source_parts']=', '.join(o.name for o in parts)
    bm=bmesh.new();bm.from_mesh(mesh)
    nonmanifold=sum(not e.is_manifold for e in bm.edges)
    degenerate=sum(f.calc_area()<1e-12 for f in bm.faces);bm.free()
    assert nonmanifold==0 and degenerate==0
    results.append({'part':label,'source_objects':[o.name for o in parts],'vertices':len(mesh.vertices),'triangles':len(mesh.loop_triangles),'pivot':list(obj.location),'nonmanifold':nonmanifold,'degenerate':degenerate,'geometry_matches_source':True})
root.location.x=0;root.location.y=0
root['optimization']='4 articulated parts, 1 PBR vertex-color material; flat-shaded GLB without redundant normals.'
root['triangles']=sum(r['triangles'] for r in results)
root['animation']='Head and both wings retain original pivots; no clips or skeleton added.'
assert root['triangles']==726
assert source_hash=={o.name:(len(o.data.vertices),len(o.data.polygons)) for o in source_root.children_recursive if o.type=='MESH'}
presentation=bpy.data.collections.new('Presentación');scene.collection.children.link(presentation)
for old in source_scene.objects:
    if old.type=='LIGHT':
        duplicate=old.copy();duplicate.data=old.data.copy();presentation.objects.link(duplicate)
floor=bpy.data.objects['Suelo de presentación'].copy();presentation.objects.link(floor)
old_camera=source_scene.camera
camera=old_camera.copy();camera.data=old_camera.data.copy();presentation.objects.link(camera)
camera.location=(1.35,-3.5,1.75);target=Vector((0,0,.38))
camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler()
camera.data.ortho_scale=1.1;scene.camera=camera
doc=bpy.data.texts.new('LEEME - Emperador optimizado')
doc.write('Versión optimizada para exportación. 726 triángulos, 4 piezas, 1 material PBR con colores por vértice.\nCabeza y aletas conservan sus pivotes. Pies y cola unidos al cuerpo.\nGLB: exportar selección y escena activa, sin normales para sombreado plano y reutilización de vértices; colores activos.\nModelo generado con asistencia de IA; referencias en el directorio original.\n')
bpy.context.window.scene=scene
for obj in scene.objects:obj.select_set(False)
root.select_set(True)
for obj in root.children:obj.select_set(True)
bpy.context.view_layer.objects.active=root
bpy.ops.export_scene.gltf(filepath=str(out/'pinguino-lowpoly-optimizado.glb'),export_format='GLB',use_selection=True,use_active_scene=True,export_animations=False,export_texcoords=False,export_normals=False,export_materials='EXPORT',export_vertex_color='ACTIVE',export_all_vertex_colors=False,export_extras=False)
bpy.data.libraries.write(str(out/'pinguino-lowpoly-optimizado.blend'),{scene,doc},fake_user=True,compress=True)
(out/'blender-verification.json').write_text(json.dumps({'source_unchanged':True,'triangles':726,'parts':results,'materials':1,'source_scene':source_scene.name,'optimized_scene':scene.name},ensure_ascii=False,indent=2))
print(json.dumps(results,ensure_ascii=False));print('SAVED',str(out))


# Concepto low-poly archivado

**Estado: archivado como exploración. La aplicación continúa con modelos voxel.**

Fecha de decisión: 14 de noviembre de 2026.

## Decisión

Se conserva el estilo voxel actual. El concepto de pingüino low-poly, incluida su versión optimizada, queda guardado como referencia para una posible revisión futura. No se incorpora a la aplicación y no queda comprometida una migración de estilo ni una fecha para retomarla.

Decisión del usuario:

> okay, vamos a archivar este concepto y vamos a dejar los voxels, estuvo buena la pruba, quizas en algun futuro lo cambiamos

## Qué se conserva

- [Escena original de comparación en Blender](pinguino-emperador-lowpoly.blend).
- [Vista comparativa de los pingüinos](comparacion-pinguino.png).
- [Modelo low-poly optimizado en Blender](optimizado/pinguino-lowpoly-optimizado.blend) y [GLB optimizado](optimizado/pinguino-lowpoly-optimizado.glb).
- [Primera comparación de rendimiento](benchmark/Comparacion-rendimiento.md).
- [Informe de optimización y nueva comparación](optimizado/Comparacion-optimizacion.md).
- Resultados crudos, verificaciones, scripts de creación y pruebas en navegador.
- [Referencias visuales y procedencia](Referencias.txt).
- [Manifiesto SHA-256 del contenido](MANIFEST-SHA256.txt).

Los informes se conservan como registro de la prueba. Sus recomendaciones exploratorias no sustituyen la decisión de este archivo.

## Aprendizaje de la prueba

La optimización mantuvo los 726 triángulos y la apariencia del low-poly, reduciendo su GLB un 73 %, sus buffers de geometría un 68 % y el tiempo mediano de CPU con 100 copias un 85 % frente a la versión anterior. El voxel continuó siendo más rápido en la comparación realizada.

Estos resultados corresponden al equipo y protocolo registrados en el informe, no a una regla universal sobre los estilos voxel y low-poly. El peso del GLB sin compresión, el tamaño comprimido, los buffers y el costo de dibujo son medidas diferentes.

## Si se retoma

Partir del modelo optimizado, revisar el estilo visual que se quiera adoptar y repetir las mediciones dentro de la aplicación con su iluminación y cantidad real de animales. Mantener los originales como referencia.

El paquete se conserva fuera del repositorio de la aplicación. No se modificó código ni se integró el modelo. Los scripts de reproducción contienen rutas locales del equipo original; revisar esas rutas si se restaura el archivo en otro lugar.

Modelo, optimización y documentación elaborados con asistencia de IA.

